package slimeLand;
import java.util.*;
import slimeLand.bag.*;

public class Item {

    
    
    public String ItemName;
    public int Itemumber;
    public int ItemResult;
    Scanner sc = new Scanner(System.in);
    String[] item = new String[5];


    

    


    // public void item() {
    //     item[0] = ItemName;
    //     item[1] = ItemName;
    //     item[2] = ItemName;
    //     item[3] = ItemName;
    // }
}
